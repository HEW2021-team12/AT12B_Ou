#pragma once

void InitGame(void);
void UninitGame(void);
void UpdateGame(void);
void DrawGame(void);
