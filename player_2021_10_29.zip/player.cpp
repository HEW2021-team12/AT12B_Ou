//=============================================================================
//
// �^�C�g����ʏ��� [title.cpp]
// Author : 
//
//=============================================================================
#include "player.h"
#include "input.h"
#include "texture.h"
#include "sprite.h"
#include "fade.h"
#include "sound.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************


//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************


//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
static int	g_PlayerTexture = 0;	
PLAYER		g_player;
float		control_timer;
float		gravity_timer;

//=============================================================================
// ����������
//=============================================================================
HRESULT InitPlayer(void)
{
	g_PlayerTexture = LoadTexture("data/TEXTURE/player.png");

	g_player.pos.x = SCREEN_WIDTH / 2;
	g_player.pos.y = SCREEN_HEIGHT / 2;
	g_player.size.x = 200.0f;
	g_player.size.y = 200.0f;
	g_player.vel.x = 5.0f;
	g_player.vel.y = 5.0f;
	g_player.rot = 0.0f;
	g_player.rot_vel = 0.1f;
	control_timer = 0.0f;
	gravity_timer = 0.0f;

	return S_OK;
}

//=============================================================================
// �I������
//=============================================================================
void UninitPlayer(void)
{
	
}

//=============================================================================
// �X�V����
//=============================================================================
void UpdatePlayer(void)
{
	/*if (GetKeyboardTrigger(DIK_RETURN) && GetFadeState() == FADE_NONE)
	{
		SceneTransition(SCENE_GAME);
	}*/
	ZeroGravity();
	ControlPlayer();
	FramePlayer();
}

//=============================================================================
// �`�揈��
//=============================================================================
void DrawPlayer(void)
{
	D3DXCOLOR col = D3DXCOLOR(1.0f,1.0f,1.0f,1.0f);

	DrawSpriteColorRotate(g_PlayerTexture, g_player.pos.x, g_player.pos.y, g_player.size.x, g_player.size.y, 0.57f, 0.04f, 0.34f, 0.38f, col, g_player.rot);
}

void ControlPlayer(void)
{
	//��(�ړ�)
	if (GetKeyboardPress(DIK_A))
	{
		g_player.pos.x -= g_player.vel.x;
		control_timer++;
		if (control_timer >= 20.0f)
		{
			g_player.rot -= g_player.rot_vel;
			control_timer = 0.0f;
		}
	}

	//�E(�ړ�)
	if (GetKeyboardPress(DIK_D))
	{
		g_player.pos.x += g_player.vel.x;
		control_timer++;
		if (control_timer >= 20.0f)
		{
			g_player.rot += g_player.rot_vel;
			control_timer = 0.0f;
		}
	}

	//��(�ړ�)
	if (GetKeyboardPress(DIK_W))
	{
		g_player.pos.y -= g_player.vel.y;
	}

	//��(�ړ�)
	if (GetKeyboardPress(DIK_S))
	{
		g_player.pos.y += g_player.vel.y;
	}

	//����]
	if (GetKeyboardPress(DIK_Q))
	{
		g_player.rot -= 0.01f;
	}

	//�E��]
	if (GetKeyboardPress(DIK_E))
	{
		g_player.rot += 0.01f;
	}
}

void FramePlayer(void)
{
	//��(�g)
	if (g_player.pos.x <= 0.0f + (g_player.size.x / 2))
	{
		g_player.pos.x = 0.0f + (g_player.size.x / 2);
	}
	//�E(�g)
	if (g_player.pos.x >= SCREEN_WIDTH - (g_player.size.x / 2))
	{
		g_player.pos.x = SCREEN_WIDTH - (g_player.size.x / 2);
	}

	//��(�g)
	if (g_player.pos.y <= 0.0f + (g_player.size.y / 2))
	{
		g_player.pos.y = 0.0f + (g_player.size.y / 2);
	}

	//��(�g)
	if (g_player.pos.y >= SCREEN_HEIGHT - (g_player.size.y / 2))
	{
		g_player.pos.y = SCREEN_HEIGHT - (g_player.size.y / 2);
	}
}

void ZeroGravity(void)
{
	if (gravity_timer < 20.0f)
	{
		g_player.pos.y -= 2.0f;
		gravity_timer++;
	}
	if (gravity_timer >= 20.0f && gravity_timer < 40.0f)
	{
		g_player.pos.y += 2.0f;
		gravity_timer++;
	}
	if (gravity_timer >= 40.0f && gravity_timer < 60.0f)
	{
		g_player.pos.y += 2.0f;
		gravity_timer++;
	}
	if (gravity_timer >= 60.0f && gravity_timer < 80.0f)
	{
		g_player.pos.y -= 2.0f;
		gravity_timer++;
	}

	if (gravity_timer >= 80.0f)
	{
		gravity_timer = 0.0f;
	}
}