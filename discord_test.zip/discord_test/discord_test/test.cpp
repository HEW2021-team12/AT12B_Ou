#include <iostream>

int main(void) {
	return 0;
}